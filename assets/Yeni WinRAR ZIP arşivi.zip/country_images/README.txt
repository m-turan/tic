Bu klasöre ülke bayrakları ekleyin:
- brazil.png (Brezilya)
- turkey.png (Türkiye)
- france.png (Fransa)
- italy.png (İtalya)
- netherlands.png (Hollanda)
- england.png (İngiltere)
- spain.png (İspanya)
- argentina.png (Arjantin)
- portugal.png (Portekiz)
- nigeria.png (Nijerya)

